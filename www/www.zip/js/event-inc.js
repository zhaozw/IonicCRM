$(function(){
  console.log('Loadding');
  var ip = location.host;
  console.log(ip);
});
